function calculatePrice() {
    let basePrice = parseFloat(document.getElementById("basePrice").value);
    let adjustment = parseFloat(document.getElementById("adjustmentValue").value);
    let direction = document.querySelector('input[name="direction"]:checked').value;

    let sqrtBase = Math.sqrt(basePrice);
    let newPrice = direction === "bullish" ? (sqrtBase + adjustment) ** 2 : (sqrtBase - adjustment) ** 2;

    alert("Calculated Price Level: " + newPrice.toFixed(6));
}
